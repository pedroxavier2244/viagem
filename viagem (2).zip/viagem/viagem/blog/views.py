from django.shortcuts import render

# Create your views here.
def blog(request):
    contexto = {
        'titulo' : 'jornada viagem |blog'
    }

    return render(request, 'blog/index.html',
                  contexto,)