from django.shortcuts import render

# Create your views here.
def destinos(request):
    contexto = {
        'titulo' : 'jornada viagem |destinos'
    }
    return render(request, 'destinos/index.html',contexto)